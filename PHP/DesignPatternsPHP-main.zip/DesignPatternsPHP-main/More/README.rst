.. meta::
   :description: a collection of advanced design patterns along with implementations in PHP8
   :keywords: design patterns, php, best practices

More
====

.. toctree::
   :titlesonly:

   ServiceLocator/README
   Repository/README
   EAV/README
