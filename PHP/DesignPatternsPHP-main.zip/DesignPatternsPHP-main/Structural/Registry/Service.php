<?php

namespace DesignPatterns\Structural\Registry;

class Service
{

}
